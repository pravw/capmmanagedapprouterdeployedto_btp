sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("ep.ui.employee.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);